//
// Created by daniel.brown1 on 4/8/19.
//

#include "Thread.h"

int Thread::quantum_usecs;

int Thread::getid(){
    return id;
}

int Thread::get_state(){
    return state;
}

int Thread::get_quantum_counter(){
    return quantum_counter;
}


void Thread::set_state(int tstate){
    if (state > BLOCKED || state < RUNNING){
        return;
    }
    state = tstate;
}

void Thread::set_quantum(int quant){
    quantum_usecs = quant;
}

jmp_buf* Thread::get_env(){
    return &env;
}