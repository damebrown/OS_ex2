//
// Created by daniel.brown1 on 4/8/19.
//

#ifndef EX2_NEW_THREAD_H
#define EX2_NEW_THREAD_H

#include <cstdio>
#include <setjmp.h>
#include <signal.h>
#include "uthreads.h"

#define RUNNING 0
#define READY 1
#define BLOCKED 2

typedef unsigned long address_t;

class Thread
{
private:
    static int quantum_usecs;
    jmp_buf env;
    int id;
    int state;
    address_t pc;
    address_t sp;
    int quantum_counter;

public:

#ifdef __x86_64__
    /* code for 64 bit architecture */

#define JB_SP 6
#define JB_PC 7

    /* A translation is required when using an address of a variable.
       Use this as a black box in your code. */
    address_t translate_address(address_t addr)
    {
        address_t ret;
        asm volatile("xor    %%fs:0x30,%0\n"
                     "rol    $0x11,%0\n"
        : "=g" (ret)
        : "0" (addr));
        return ret;
    }

#else
    /* code for 32 bit architecture*/

typedef unsigned int address_t;
#define JB_SP 4
#define JB_PC 5

/* A translation is required when using an address of a variable.
   Use this as a black box in your code. */
address_t translate_address(address_t addr)
{
    address_t ret;
    asm volatile("xor    %%gs:0x18,%0\n"
        "rol    $0x9,%0\n"
                 : "=g" (ret)
                 : "0" (addr));
    return ret;
}

#endif


    Thread(const int _id, const int _state, address_t _f, address_t _sp) : id(_id), state(_state)
//    , pc(_f) , sp((address_t)_sp + STACK_SIZE - sizeof(address_t)), quantum_counter(0){
        , pc(_f) , sp(_sp), quantum_counter(0){
        sigsetjmp(env, 1);
        (env->__jmpbuf)[JB_SP] = translate_address(sp);
        (env->__jmpbuf)[JB_PC] = translate_address(pc);
        sigemptyset(&env->__saved_mask);
    };
    ~Thread() = default;
//    ~Thread(){
//    delete sp;};
    int getid();
    int get_state();
    int get_quantum_counter();
    void set_state(int tstate);
    void quant_inc() {quantum_counter++;}
    static void set_quantum(int quant);
    jmp_buf* get_env();



};


#endif //EX2_NEW_THREAD_H
