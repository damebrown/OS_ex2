//
// Created by daniel.brown1 on 4/1/19.
//

#include "uthreads.h"
#include "Thread.h"
#include <stdio.h>
#include <stdlib.h>
#include <queue>
#include <deque>
#include <signal.h>
#include <sys/time.h>
#include <vector>
#include <iostream>
#include <sys/time.h>
#include "sleeping_threads_list.h"


/**Global Variables**/


itimerval timer;
struct sigaction sig_handler;

//0 if quant, 1 if terminate or block
bool sig_mask = false;
unsigned long current_thread = 0;
int total_quants = 0;
int thr_count = 0;
int case_flag = 0;
SleepingThreadsList sleeping_threads_list;
std::vector<Thread *> threads(MAX_THREAD_NUM);
std::deque<Thread *> ready_q;


void timer_handler(int sig)
{
    if (sig_mask)
    {
        return;
    }
    timeval now;
    gettimeofday(&now, nullptr);
    wake_up_info *first_sleeper = sleeping_threads_list.peek();
    if ((first_sleeper != NULL))
    {
        bool sec = (now.tv_sec - first_sleeper->awaken_tv.tv_sec >= 0);
        bool usec = (now.tv_usec - first_sleeper->awaken_tv.tv_usec >= 0);
        while (sec && usec)
        {
            uthread_resume(first_sleeper->id);
            sleeping_threads_list.pop();
            first_sleeper = sleeping_threads_list.peek();
            if (first_sleeper == NULL)
            {
                break;
            }
            sec = (now.tv_sec - first_sleeper->awaken_tv.tv_sec >= 0);
            usec = (now.tv_usec - first_sleeper->awaken_tv.tv_usec >= 0);
        }
    }
    switch (case_flag)
    {
        case 0:
        {
            total_quants++;
            int ret_val = sigsetjmp(*threads.at(current_thread)->get_env(), 1);
            if (ret_val == 1)
            {
                unsigned long temp = current_thread;
                current_thread = (unsigned long) ready_q.front()->getid();
                threads[current_thread]->set_state(RUNNING);
                threads[current_thread]->quant_inc();
                ready_q.pop_front();
                uthread_resume((int) temp);
                return;
            }
            siglongjmp(*threads.at(current_thread)->get_env(), 1);
        }
        case 1:
        {
            current_thread = (unsigned long) ready_q.front()->getid();
            threads[current_thread]->set_state(RUNNING);
            threads[current_thread]->quant_inc();
            ready_q.pop_front();
            break;
        }
        default:
            return;
    }
    case_flag = 0;
}


int reset_timer(int quantum_usecs)
{
    sig_handler.sa_handler = &timer_handler;
    if (sigaction(SIGVTALRM, &(sig_handler), nullptr) < 0)
    {
        std::cerr << "system error: sigaction error" << endl;
    }
    timer.it_value.tv_sec = 0;
    timer.it_value.tv_usec = quantum_usecs;

    timer.it_interval.tv_sec = 0;
    timer.it_interval.tv_usec = quantum_usecs;
    if (setitimer(ITIMER_VIRTUAL, &timer, nullptr))
    {
        std::cerr << "system error: set timer error" << endl;
    }
    return 0;
}

/*
 * Description: This function initializes the Thread library.
 * You may assume that this function is called before any other Thread library
 * function, and that it is called exactly once. The input to the function is
 * the length of a quantum in micro-seconds. It is an error to call this
 * function with non-positive quantum_usecs.
 * Return value: On success, return 0. On failure, return -1.
*/
int uthread_init(int quantum_usecs)
{
    if (quantum_usecs <= 0)
    {
        std::cerr << "thread library error: negative quantum input" << endl;
        return -1;
    }
    char *stack = (new char[MAX_THREAD_NUM]);
    threads.at(0) = new Thread(0, RUNNING, 0, (address_t) (&stack));
    if (threads.at(0) == nullptr)
    {
        std::cerr << "system error: thread allocation failed" << endl;
    }
    threads.at(0)->quant_inc();
    Thread::set_quantum(quantum_usecs);
    total_quants++, thr_count++;
    reset_timer(quantum_usecs);
    return 0;
}

/*
 * Description: This function creates a new Thread, whose entry point is the
 * function f with the signature void f(void). The Thread is added to the end
 * of the READY threads list. The uthread_spawn function should fail if it
 * would cause the number of concurrent threads to exceed the limit
 * (MAX_THREAD_NUM). Each Thread should be allocated with a stack of size
 * STACK_SIZE bytes.
 * Return value: On success, return the ID of the created Thread.
 * On failure, return -1.
*/
int uthread_spawn(void (*f)(void))
{
    if (thr_count == 100)
    {
        std::cerr << "thread library error: threads amout is maximal" << endl;
        return -1;
    }
    int i;
    auto _f = (address_t) f;
    for (i = 1; i < MAX_THREAD_NUM; ++i)
    {
        if (threads[i] == nullptr)
        {
            char *stack = (new char[MAX_THREAD_NUM]);
            threads[i] = new Thread(i, READY, _f, (address_t) (stack));
            if (threads.at(0) == nullptr)
            {
                std::cerr << "system error: thread allocation failed" << endl;
            }
            ready_q.push_back(threads[i]);
            total_quants++, thr_count++;
            return i;
        }
    }
    std::cerr << "thread library error: failed to spawn new thread" << endl;
    return -1;
}

/**
 * This function handles the case where thread 0 is being terminated. Deletes all of the library's
 * data structures.
 */
void exit_process()
{
    unsigned long i;
    while (!ready_q.empty())
    {
        ready_q.pop_back();
    }
    while (sleeping_threads_list.peek())
    {
        sleeping_threads_list.pop();
    }
    for (i = 0; i < MAX_THREAD_NUM; ++i)
    {
        if (threads.at(i) != nullptr)
        {
            delete (threads.at(i));
        }
    }
    threads.clear();
    exit(0);
}

/*
 * this function updates the ready threads queue in case of blocking a thread whose state is ready.
 * @param tid- the id of the thread to block
 */
void delete_from_ready_q(int tid)
{
    for (auto it = ready_q.begin(); it != ready_q.end(); ++it)
    {
        if ((*it)->getid() == tid)
        {
            it = ready_q.erase(it);
            break;
        }
    }
}


/*
 * Description: This function terminates the Thread with ID tid and deletes
 * it from all relevant control structures. All the resources allocated by
 * the library for this Thread should be released. If no Thread with ID tid
 * exists it is considered an error. Terminating the main Thread
 * (tid == 0) will result in the termination of the entire process using
 * exit(0) [after releasing the assigned library memory].
 * Return value: The function returns 0 if the Thread was successfully
 * terminated and -1 otherwise. If a Thread terminates itself or the main
 * Thread is terminated, the function does not return.
*/
int uthread_terminate(int tid)
{
    bool running = false;
    if ((threads.at((unsigned long) tid) == nullptr) | (tid < 0) | (tid > 99))
    {
        std::cerr << "thread library error: invalid thread id input for terminate" << endl;
        return -1;
    }
    if (!tid)
    {
        sig_mask = true;
        exit_process();
        sig_mask = false;
    }
    if (threads.at((unsigned long) tid)->get_state() == READY)
    {
        sig_mask = true;
        delete_from_ready_q(tid);
        sig_mask = false;
    }
    if (threads[tid]->get_state() == RUNNING)
    {
        running = true;
    }
    delete (threads.at((unsigned long) tid));
    threads.at((unsigned long) tid) = nullptr;
    thr_count--;
    if (running)
    {
        case_flag = 1;
        timer_handler(SIGINT);
    }
    return 0;
}

/*
 * Description: This function blocks the Thread with ID tid. The Thread may
 * be resumed later using uthread_resume. If no Thread with ID tid exists it
 * is considered as an error. In addition, it is an error to try blocking the
 * main Thread (tid == 0). If a Thread blocks itself, a scheduling decision
 * should be made. Blocking a Thread in BLOCKED state has no
 * effect and is not considered an error.
 * Return value: On success, return 0. On failure, return -1.
*/
int uthread_block(int tid)
{
    auto u_tid = (unsigned long) tid;
    if ((u_tid < 1) | (u_tid > 99))
    {
        std::cerr << "thread library error: tried to block a thread with non valid id" << endl;
        return -1;
    }
    if (threads.at(u_tid) == NULL)
    {
        std::cerr << "thread library error: tried to block a null thread" << endl;
        return -1;
    }
    if (threads.at(u_tid)->get_state() == READY)
    {
        sig_mask = true;
        delete_from_ready_q(tid);

    }
    threads.at(u_tid)->set_state(BLOCKED);
    sig_mask = false;
    if (tid == (int)current_thread)
    {
        case_flag = 1;
        timer_handler(SIGINT);
        reset_timer(threads.at(u_tid)->get_quantum_counter());
    }
    return 0;
}

/*
 * Description: This function resumes a blocked Thread with ID tid and moves
 * it to the READY state. Resuming a Thread in a RUNNING or READY state
 * has no effect and is not considered as an error. If no Thread with
 * ID tid exists it is considered an error.
 * Return value: On success, return 0. On failure, return -1.
*/
int uthread_resume(int tid)
{
    sig_mask = true;
    auto u_tid = (unsigned long) tid;
    if (threads.at(u_tid) == nullptr)
    {
        std::cerr << "thread library error: tried to resume a non existing thread" << std::endl;
        return -1;
    }
    threads.at(u_tid)->set_state(READY);
    ready_q.push_back(threads[tid]);
    sig_mask = false;
    return 0;
}

timeval calc_wake_up_timeval(int usecs_to_sleep)
{

    timeval now, time_to_sleep, wake_up_timeval;
    gettimeofday(&now, nullptr);
    time_to_sleep.tv_sec = usecs_to_sleep / 1000000;
    time_to_sleep.tv_usec = usecs_to_sleep % 1000000;
    timeradd(&now, &time_to_sleep, &wake_up_timeval);
    return wake_up_timeval;
}

/*
 * Description: This function blocks the RUNNING Thread for usecs micro-seconds in real time (not virtual
 * time on the cpu). It is considered an error if the main Thread (tid==0) calls this function. Immediately after
 * the RUNNING Thread transitions to the BLOCKED state a scheduling decision should be made.
 * After the sleeping time is over, the Thread should go back to the end of the READY threads list.
 * Return value: On success, return 0. On failure, return -1.
*/
int uthread_sleep(unsigned int usec)
{
    sig_mask = true;
    auto id = current_thread;
    if (!id)
    {
        std::cerr << "thread library error: tried to sleep the main thread" << std::endl;
        return -1;
    }
    uthread_block((int) id);
    sleeping_threads_list.add((int) id, calc_wake_up_timeval(usec));
    sig_mask = false;
    return 0;
}


/*
 * Description: This function returns the Thread ID of the calling Thread.
 * Return value: The ID of the calling Thread.
*/
int uthread_get_tid()
{
    return (int) current_thread;
}

/*
 * Description: This function returns the total number of quantums since
 * the library was initialized, including the current quantum.
 * Right after the call to uthread_init, the value should be 1.
 * Each time a new quantum starts, regardless of the reason, this number
 * should be increased by 1.
 * Return value: The total number of quantums.
*/
int uthread_get_total_quantums()
{
    return total_quants;
}

/*
 * Description: This function returns the number of quantums the Thread with
 * ID tid was in RUNNING state. On the first time a Thread runs, the function
 * should return 1. Every additional quantum that the Thread starts should
 * increase this value by 1 (so if the Thread with ID tid is in RUNNING state
 * when this function is called, include also the current quantum). If no
 * Thread with ID tid exists it is considered an error.
 * Return value: On success, return the number of quantums of the Thread with ID tid.
 * 			     On failure, return -1.
*/
int uthread_get_quantums(int tid)
{
    if (threads.at((unsigned long) tid) != NULL)
    {

        return threads.at((unsigned long) tid)->get_quantum_counter();
    }
    std::cerr << "thread library error: tried to sleep the main thread" << std::endl;
    return -1;
}
